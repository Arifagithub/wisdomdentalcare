									<!-- script -->
                                    <script type="text/javascript">
                                        $(document).ready(function(){
                                            $('#e<?php echo $id; ?>').tooltip('show')
                                            $('#e<?php echo $id; ?>').tooltip('hide')
                                        });
                                    </script>
                                    <!-- end script -->
                                    <!-- script -->
                                    <script type="text/javascript">
                                        $(document).ready(function(){
                                            
                                            $('#<?php echo $id; ?>').tooltip('show')
                                            $('#<?php echo $id; ?>').tooltip('hide')
                                        });
                                    </script>
                                    <!-- end script -->